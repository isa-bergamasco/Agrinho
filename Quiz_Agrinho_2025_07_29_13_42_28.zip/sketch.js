function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let perguntas = [
  {
    texto: "Qual tem melhor localização",
    opcoes: ["Cidade", "Campo", ],
    respostaCorreta: 0
  },
  {
    texto: "O campo está ligado a cidade?",
    opcoes: ["não", "sim", ],
    respostaCorreta: 1
  },
  {
    texto: "a tecnologia é importate para o campo?",
    opcoes: ["não", "sim", ],
    respostaCorreta: 1
  }
];

let perguntaAtual = 0;
let respostasSelecionadas = [];

function setup() {
  createCanvas(600, 400);
  textSize(16);
}

function draw() {
  background(220,);
  if (perguntaAtual < perguntas.length) {
    exibirPergunta();
  } else {
    exibirResultado();
  }
}

function exibirPergunta() {
  let p = perguntas[perguntaAtual];
  text(`Pergunta ${perguntaAtual + 1}: ${p.texto}`, 20, 50);
  for (let i = 0; i < p.opcoes.length; i++) {
    fill(255, 0, 80);
    rect(20, 80 + i * 40, 560, 30);
    fill(0);
    text(p.opcoes[i], 30, 100 + i * 40);
  }
}

function mousePressed() {
  if (perguntaAtual < perguntas.length) {
    for (let i = 0; i < perguntas[perguntaAtual].opcoes.length; i++) {
      let y = 80 + i * 40;
      if (
        mouseX > 20 &&
        mouseX < 580 &&
        mouseY > y &&
        mouseY < y + 30
      ) {
        respostasSelecionadas[perguntaAtual] = i;
        perguntaAtual++;
        break;
      }
    }
  }
}

function exibirResultado() {
  let acertos = 0;
  for (let i = 0; i < perguntas.length; i++) {
    if (respostasSelecionadas[i] === perguntas[i].respostaCorreta) {
      acertos++;
    }
  }
  text(`Você acertou ${acertos} de ${perguntas.length} perguntas!`, 20, 50);
}